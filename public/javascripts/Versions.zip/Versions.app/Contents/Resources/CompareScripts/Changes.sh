#!/bin/bash

CHANGES=`"$VERSIONS_LOCATION"/Contents/MacOS/FindApplication com.skorpiostech.Changes`
"$CHANGES/Contents/Resources/chdiff" "$1" "$2"